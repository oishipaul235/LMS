<?php
include("../database.php");
class user{
    function __construct()
    {
        $this->database = Database::getInstance();
    }

    public function checkUserInfo( $email, $pass)
    {
        $query = "SELECT * FROM users where `email` = '$email' and `password` = '$pass'";
        $result =  $this->database->connection()->query($query);
        if ($result && $result->num_rows) { //if data inserted successfully
            $_SESSION['token'] = $email;
            header("Location: ../index.php");
        } else {
           
            return true;
        }
    }
    public function signup($name,$email,$password,$phone,$address)
    {
       $query=" INSERT INTO `users`(`id`, `name`, `email`, `password`, `phone`, `address`, `created_at`) VALUES ('','$name','$email','$password','$phone','$address','')";
       $result =  $this->database->connection()->query($query);
       if ($result ) { //if data inserted successfully
           $_SESSION['token'] = $email;
           header("Location: ../index.php");
       }
    }
}