<?php session_encode();?>
<footer>
<div class="footer-top">
<div class="container5" style="padding:20px; background-color:wheat">
<div class="row">
   <div class="col-md-3 col-sm-6 col-xs-12 segment-one">
    <h2>Features</h2>
    <ul style="list-style-type: none;">
    <li><a href="#">Jobs</a></li>
    <li><a href="#">Brand Assets</a></li>
    <li><a href="#">Investor Relations</a></li>
    <li><a href="#">Terms of Service</a></li>
  </ul></div>
<div class="col-md-3 col-sm-6 col-xs-12 segment-two">
<h2>Resources</h2>
                    <ul style="list-style-type: none;">
                     <li><a href="#">Guides</a></li>
                        <li><a href="#">Research</a></li>
                        <li><a href="#">Experts</a></li>
                        <li><a href="#">Agencies</a></li>
                  </ul></div>
                  <div class="col-md-3 col-sm-6 col-xs-12 segment-three">
                  <h2>Quick Links</h2>
                    <ul style="list-style-type: none;">
                        <li><a href="#">Jobs</a></li>
                        <li><a href="#">Brand Assets</a></li>
                        <li><a href="#">Investor Relations</a></li>
                        <li><a href="#">Terms of Service</a></li>
                    </ul></div>
        <div class="col-md-3 col-sm-6 col-xs-12 segment-four">
        <h2>Follow us</h2>
         <p>You can trust us.</p>
          </div>
</div>
</div>
</div>
</footer>