<?php session_start();?>
<header>
  <h2><ul class="nav justify-content-center">
    <li class="nav-item">
    <a class="nav-link disabled" href="#">LMS</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" href="index.php">HOME</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="courses.php">COURSES</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="discussion.php">DISCUSSION</a>
  </li>
  <li class="nav-item">
    <a class="nav-link " href="./signup/signup.php">SIGN UP</a>
  </li>
</ul>
</h2>
</header>