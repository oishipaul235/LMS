<?php 
    include('./model/Course.php');
    $courseObj = new Course();
   
    $result = $courseObj->fetchAllCourse();
    
    while ($course = mysqli_fetch_assoc($result)) { ?>
<div class="col-md-4">
    <div class="card">
        <div class="card-header">
            <img style="max-width: 313px;margin: auto;" src="./images/<?php printf($course['image']) ?>"
                class="course-image" />
        </div>
        <div class="card-body">
            <h2><?php printf($course['name']); ?></h2>
            <span>Duration: <?php printf($course['duration']); ?></span><br>
            <span>Price: <?php printf($course['price']); ?></span><br><br>
            <p class="card course-info"><?php printf($course['description']); ?></p>
        </div>
        
    </div>
</div>
<?php } ?>