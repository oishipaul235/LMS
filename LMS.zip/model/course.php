<?php
include("./database.php");
class course
{
    function __construct()
    {
        $this->database = Database::getInstance();
    }

    public function fetchAllCourse()
    {
        $query = "SELECT * FROM courses";
        $result =  $this->database->connection()->query($query);
        return $result;
    }
}