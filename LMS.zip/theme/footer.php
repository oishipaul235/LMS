<?php session_encode();?>
<footer>
<div class="container1" style="text-align:center; background-color:LavenderBlush ;width:1334px;height:250px;padding:15px;">
            <div class="row">

                <div class="col-lg-2 col-md-6 single-footer-widget">
                    <h4>Top Products</h4>
                    <ul style="list-style-type: none;">
                        <li><a href="#">Managed Website</a></li>
                        <li><a href="#">Manage Reputation</a></li>
                        <li><a href="#">Power Tools</a></li>
                        <li><a href="#">Marketing Service</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6 single-footer-widget">
                    <h4>Quick Links</h4>
                    <ul style="list-style-type: none;">
                        <li><a href="#">Jobs</a></li>
                        <li><a href="#">Brand Assets</a></li>
                        <li><a href="#">Investor Relations</a></li>
                        <li><a href="#">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6 single-footer-widget">
                    <h4>Features</h4>
                    <ul style="list-style-type: none;">
                        <li><a href="#">Jobs</a></li>
                        <li><a href="#">Brand Assets</a></li>
                        <li><a href="#">Investor Relations</a></li>
                        <li><a href="#">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6 single-footer-widget">
                    <h4>Resources</h4>
                    <ul style="list-style-type: none;">
                        <li><a href="#">Guides</a></li>
                        <li><a href="#">Research</a></li>
                        <li><a href="#">Experts</a></li>
                        <li><a href="#">Agencies</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-6 single-footer-widget">
                    <h4>Newsletter</h4>
                    <p>You can trust us. we only send promo offers,</p>

                </div>

                <div class="footer-bottom row align-items-center">
                    <p class="footer-text m-0 col-lg-8 col-md-12">
                        Copyright All rights reserved
                    </p>
                    <div class="col-lg-4 col-md-12 footer-social">
                        <p><a href="#"><span class="fa fa-facebook fa-2x"></span></a></p>
                        <p><a href="#"><span class="fa fa-google fa-2x"></span></a></p>
                        <p><a href="#"><span class="fa fa-instagram fa-2x"></span></a></p>
                        <p><a href="#"><span class="fa fa-twitter fa-2x"></span></a></p>
                        <p> &copy;Online learning System . Privacy. Terms & Conditions</p>
                    </div>
                </div>
            </div>
        </div>

</footer>