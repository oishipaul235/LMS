<?php
include("./theme/header.php");
?>
<html>

<head>
    <meta charset="utf-8">
    <title>Course Page</title>
    <link rel="stylesheet" type="text/css" href="./css/bootstrap.css">
    <!-- <link rel="stylesheet" type="text/css" href="./css/home.css">  -->
    <style>
    ul {
        list-style-type: none;
      
    }

    .jumbotron {
        background-position: top center;
        background-size: cover;
        height: 1000px;

    }

    .card body {
        max-height: 800px;
    }

    .card header {
        margin: 10px;
        padding: 10px;
        width: 80px;
        height: 50px
    }

    
    </style>
</head>

<body>
    
    <section>
        <div class="jumbotron" style="background-image:url('./images/course.jpg')">
            <h1 style="font-family:Broadway;padding:60px;margin:20px;text-align:right;"> Courses
            </h1>
            <h2>
                <p style="font-family:arial rounded mt bold;padding:60px;margin:20px;text-align:right;">In the history
                    of modern astronomy,<br> there is probably no one greater leap forward than the building.
                </p>
            </h2>
        </div>
    </section>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <img style="height:250px;width:300px;padding:2px;margin:5px;" src="./images/c.jpg" />
                        </div>
                        <div class="card-body">
                            <h1>C Programming</h1>
                            <span>Duration: 35hr</span><br>
                            <span>Price: INR 1200</span><br><br>
                            <p class="card course-info">HTML,CSS,JS,PHP</p>
                        </div>
                        <div class="card-footer">
                            <a href='coursedetails1.php'><button class="btn btn-primary">View Course</button>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <img style="height:250px;width:300px;padding:2px;margin:5px;" src="./images/c++.jpg" />
                        </div>
                        <div class="card-body">
                            <h1>C++ </h1>
                            <span>Duration: 35hr</span><br>
                            <span>Price: INR 1200</span><br><br>
                            <p class="card course-info">Learn something new.</p>
                        </div>
                        <div class="card-footer">
                            <a href='coursedetails2.php'>
                                <button class="btn btn-primary">View Course</button>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <img style="height:250px;width:300px;padding:2px;margin:5px;" src="./images/java.jpg" />
                        </div>
                        <div class="card-body">
                            <h1>JAVA</h1>
                            <span>Duration: 35 Hours</span><br>
                            <span>Price: INR 12000</span><br><br>
                            <p class="card course-info">In the history of modern astronomy, there is probably no one
                                greater leap forward than the building and launch of the space telescope known as the
                                Hubble.
                            </p>
                        </div>
                        <div class="card-footer">
                            <a href='coursedetails3.php'>
                                <button class="btn btn-primary">View Course</button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <?php
include("./theme/footer.php");
?>
        
</body>

</html>