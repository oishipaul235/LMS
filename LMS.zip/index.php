<html>

<head>
    <meta charset="utf-8">
    <title>Home Page</title>
    <link rel="stylesheet" type="text/css" href="./css/bootstrap.css">
    <!-- <link rel="stylesheet" type="text/css" href="./css/home.css">  -->
    <style>
    ul {
        list-style-type: none;
    
    }

    .jumbotron {
        background-position: top center;
        background-size: cover;
        height: 800px;
      
    }

    .card body {
        max-height: 800px;
    }

    .card header {
        margin: 10px;
        padding: 10px;
        width: 80px;
        height: 50px
    }

    .container1 {
        text-align: center;
    }
    </style>
</head>

<body>
    <header>

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <h1 > <a class="navbar-brand" href="#">LMS</a></h1>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">HOME<span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="courses.php">COURSES</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">CONTACT</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./signup/signup.php">SIGN UP</a>
                        </li>
                    </ul>
                
                <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                </form>
            </div>
        </nav>

    </header>
    <section>
        <div class="jumbotron" style="background-image:url('./images/STUDY.jpg')">
            <h1 style="font-family:Broadway;padding:60px;margin:20px;color:white"> Take the first step <br>to learn with
                us
            </h1>
            <h2>
                <p style="font-family:arial rounded mt bold;padding:60px;margin:20px;">In the history of modern
                    astronomy,<br> there is probably no one
                    greater leap<br> forward than the building and launch of the space <br>
                    telescope known as the Hubble.
                </p>
            </h2>
        </div>
    </section>
    <section>
        <div class="container">
            <div class="row">
                <?php include('./partials/course-list.php'); ?>
            </div>
        </div>
    </section>
    <footer style="background-color:LavenderBlush;width:1334px;height:250px;padding:15px;">
        <div class="container1">
            <div class="row">

                <div class="col-lg-2 col-md-6 single-footer-widget">
                    <h4>Top Products</h4>
                    <ul>
                        <li><a href="#">Managed Website</a></li>
                        <li><a href="#">Manage Reputation</a></li>
                        <li><a href="#">Power Tools</a></li>
                        <li><a href="#">Marketing Service</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6 single-footer-widget">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="#">Jobs</a></li>
                        <li><a href="#">Brand Assets</a></li>
                        <li><a href="#">Investor Relations</a></li>
                        <li><a href="#">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6 single-footer-widget">
                    <h4>Features</h4>
                    <ul>
                        <li><a href="#">Jobs</a></li>
                        <li><a href="#">Brand Assets</a></li>
                        <li><a href="#">Investor Relations</a></li>
                        <li><a href="#">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6 single-footer-widget">
                    <h4>Resources</h4>
                    <ul>
                        <li><a href="#">Guides</a></li>
                        <li><a href="#">Research</a></li>
                        <li><a href="#">Experts</a></li>
                        <li><a href="#">Agencies</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-6 single-footer-widget">
                    <h4>Newsletter</h4>
                    <p>You can trust us. we only send promo offers,</p>

                </div>

                <div class="footer-bottom row align-items-center">
                    <p class="footer-text m-0 col-lg-8 col-md-12">
                        Copyright All rights reserved
                    </p>
                    <div class="col-lg-4 col-md-12 footer-social">
                        <p><a href="#"><span class="fa fa-facebook fa-2x"></span></a></p>
                        <p><a href="#"><span class="fa fa-google fa-2x"></span></a></p>
                        <p><a href="#"><span class="fa fa-instagram fa-2x"></span></a></p>
                        <p><a href="#"><span class="fa fa-twitter fa-2x"></span></a></p>
                        <p> &copy;Online learning System . Privacy. Terms & Conditions</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>