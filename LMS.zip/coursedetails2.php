<html>

<head>
    <meta charset="utf-8">
    <title>Home Page</title>
    <link rel="stylesheet" type="text/css" href="./css/bootstrap.css">
    <!-- <link rel="stylesheet" type="text/css" href="./css/home.css">  -->
    <style>
  
    

    .jumbotron {
        background-position: top center;
        background-size: cover;
        height: 800px;
        
    }
    .card{
    background-position: center;
    height: 1000px;
    width: 1300px;
    text-align: center;
}
    .card body{
        max-height:800px;

    }
    .card header {
        margin: 10px;
        padding: 10px;
        width: 1500px;
        height: 150px;
    }
    
    
    </style>
</head>

<body>
<?php
include("./theme/header.php");
?>
    <section>
        <div class="jumbotron" style="background-image:url('./images/coursedetails.jpg')">
            <h1 style="font-family:Broadway;padding:60px;margin:20px;text-align:right;"> Course Details
            </h1>
            <h2><p style="font-family:arial rounded mt bold;padding:60px;margin:20px;text-align:right;">In the history of modern astronomy,<br> there is probably no one
                greater leap<br> forward than the building and launch of the space <br>
                telescope known as the Hubble.
            </p></h2>
        </div>
    </section>
    <section class="course-details-area section-gap">
    <div class="card">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 course-details-left">
                    <div class="main-image">
                    <div class="card-header">
                        <img class="img-fluid" src="./images/c++.jpg" alt="">
                    </div></div>
                    <div class="content-wrapper">
                    <div class="card-body" style="text-align:left;">
                        <h4 class="title"><u>Objectives</u></h4>
                        <div class="content">
                            When you enter into any new area of science, you almost always find yourself with a
                            baffling new language of
                            technical terms to learn before you can converse with the experts. This is certainly
                            true in astronomy both in
                            terms of terms that refer to the cosmos and terms that describe the tools of the trade,
                            the most prevalent
                            being the telescope.
                            <br>
                            <br>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore
                            magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
                            ut aliquip ex ea
                            commodoconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum. Lorem ipsum dolor sit
                            amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim
                            ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                            commodo consequat. Duis aute
                            irure dolor in reprehenderit in voluptate velit esse cillum.
                        </div>

                        <h4 class="title"><u>Eligibility</u></h4>
                        <div class="content">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore
                            magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
                            ut aliquip ex ea commodo
                            consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.
                            <br>
                            <br>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore
                            magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
                            ut aliquip ex ea
                            commodoconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum. Lorem ipsum dolor sit
                            amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim
                            ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                            commodo consequat. Duis aute
                            irure dolor in reprehenderit in voluptate velit esse cillum.
                        </div>
                        </div></div>
                        </div>
                        </div>
                        </div>
                        </div>
                        <?php
include("./theme/footer.php");
?>
</body>

</html>